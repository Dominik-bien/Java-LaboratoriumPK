import java.util.LinkedList;
public class Stack<T>{
    private LinkedList<T> list;

    public Stack() {
        list = new LinkedList<>();
    }
    public void push(T t) {
        list.addFirst(t);
    }
    public T pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return list.removeFirst();
    }
    public T peek() {
        return list.getFirst();
    }
    public boolean isEmpty() {
        return list.isEmpty();
    }
    public int size() {
        return list.size();
    }
    public int find(T element) {
        if (element == null)
            throw new NullPointerException("Null is not a valid element");
        int index = list.indexOf(element);
        if (index == -1)
            throw new IllegalArgumentException("Element is not in the stack");

        System.out.print("Element " + element + " is at index ");

        return  index;
    }

    @Override
    public String toString() {
        return "Stack{" + "list=" + list + '}';
    }




}
