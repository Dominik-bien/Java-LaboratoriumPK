//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Stack <Integer> stack = new Stack<>();


        stack.push(88);
        stack.push(31);
        stack.push(42);
        stack.push(12);
        stack.push(13);
        stack.push(-114);

        System.out.println(stack);

        System.out.println("Stack peak: " + stack.peek());
        System.out.println("Stack pop: " + stack.pop());
        System.out.println("Stack after peek: " + stack);
        System.out.println("Size stack after pop: " + stack.size());
        System.out.println("Stack is empty? " + stack.isEmpty());
        System.out.println(stack.find(42));



        }
    }
