public  class Test implements Comparable<Test> {
    private int value;

    public Test(int value) {
        this.value = value;
    }

    @Override
    public int compareTo(Test other) {
        return Integer.compare(this.value, other.value);
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}