public class Main {
public static void main(String[] args) throws Exception {
    Set<Test> setA = new Set<>(5);
    setA.dodajElement(new Test(3));
    setA.dodajElement(new Test(1));
    setA.dodajElement(new Test(2));
    System.out.println(setA);

    Set<Test> setB = new Set<>(5);
    setB.dodajElement(new Test(4));
    setB.dodajElement(new Test(2));
    setB.dodajElement(new Test(5));
    System.out.println("Zbiór B: " + setB);

    // Operacja dodawania elementów z obu zbiorów
    Set<Test> unionSet = setA.dodajElementy(setB);
    System.out.println("Zbiór A + B (dodajElementy): " + unionSet);

    // Operacja odejmowania elementów zbioru B od zbioru A
    Set<Test> differenceSet = setA.odejmijElementy(setB);
    System.out.println("Zbiór A - B (odejmijElementy): " + differenceSet);

    // Operacja przecięcia zbiorów A i B
    Set<Test> intersectionSet = setA.przeciecie(setB);
    System.out.println("Zbiór A ∩ B (przeciecie): " + intersectionSet);



}
}