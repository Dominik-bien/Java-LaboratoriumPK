import java.util.Arrays;

public class Set<T extends Comparable<T>> {
    private T[] set;
    private int pojemnosc;
    private int rozmiar;

    @SuppressWarnings("unchecked")
    public Set(int pojemnosc) {
        this.pojemnosc = pojemnosc;
        this.set = (T[]) new Comparable[pojemnosc];
        this.rozmiar = 0;
    }

    public void dodajElement(T element) throws Exception {
        if (rozmiar >= pojemnosc) {
            throw new Exception("Zbiór jest pełny!");
        }

        for (int i = 0; i < rozmiar; i++) {
            if (set[i].compareTo(element) == 0) {
                return; // Element już istnieje
            }
        }

        set[rozmiar++] = element;
        Arrays.sort(set, 0, rozmiar); // Sortujemy tylko aktualne elementy
    }

    public int szukaj(T element) {
        for (int i = 0; i < rozmiar; i++) {
            if (set[i].compareTo(element) == 0) {
                return i;
            }
        }
        return -1; // Element nie znaleziony
    }

    public void usunElement(T element) {
        int index = szukaj(element);
        if (index == -1) {
            return;
        }

        for (int i = index; i < rozmiar - 1; i++) {
            set[i] = set[i + 1];
        }
        rozmiar--;
    }

    public Set<T> dodajElementy(Set<T> other) {
        Set<T> result = new Set<>(this.pojemnosc + other.pojemnosc);

        for (int i = 0; i < this.rozmiar; i++) {
            try {
                result.dodajElement(this.set[i]);
            } catch (Exception ignored) {
            }
        }

        for (int i = 0; i < other.rozmiar; i++) {
            try {
                result.dodajElement(other.set[i]);
            } catch (Exception ignored) {
            }
        }

        return result;
    }

    public Set<T> odejmijElementy(Set<T> other) {
        Set<T> result = new Set<>(this.pojemnosc);

        for (int i = 0; i < this.rozmiar; i++) {
            if (other.szukaj(this.set[i]) == -1) {
                try {
                    result.dodajElement(this.set[i]);
                } catch (Exception ignored) {
                }
            }
        }

        return result;
    }

    public Set<T> przeciecie(Set<T> other) {
        Set<T> result = new Set<>(Math.min(this.pojemnosc, other.pojemnosc));

        for (int i = 0; i < this.rozmiar; i++) {
            if (other.szukaj(this.set[i]) != -1) {
                try {
                    result.dodajElement(this.set[i]);
                } catch (Exception ignored) {
                }
            }
        }

        return result;
    }

    @Override
    public String toString() {
        return "Rozmiar: " + rozmiar + ", Pojemnosc: " + pojemnosc + ", Elementy: " + Arrays.toString(Arrays.copyOf(set, rozmiar));
    }
}