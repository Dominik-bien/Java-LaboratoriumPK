import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBManager {
    private static final String URL = "jdbc:mysql://localhost:3306/quizDB?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private static Connection conn;

    public static void initializeDatabase() {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/?serverTimezone=UTC", USER, PASSWORD);
             Statement stmt = connection.createStatement()) {

            ResultSet rs = stmt.executeQuery("SHOW DATABASES LIKE 'quizDB'");
            if (!rs.next()) {
                stmt.executeUpdate("CREATE DATABASE quizDB");
                System.out.println("Utworzono nową bazę danych quizDB.");
            } else {
                System.out.println("Baza danych już istnieje.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            Statement stmt = conn.createStatement();

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS questions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    question TEXT,
                    answerA TEXT,
                    answerB TEXT,
                    answerC TEXT,
                    answerD TEXT,
                    correctAnswer CHAR(1)
                )
            """);

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS results (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(100),
                    score INT,
                    total INT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """);

            // Import z pliku tylko jeśli tabela jest pusta
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM questions");
            rs.next();
            int count = rs.getInt(1);
            if (count == 0) {
                System.out.println("Importuję dane startowe z bazaPytan.txt...");
                new DBManager().importFromFile("src/bazaPytan.txt");
            } else {
                System.out.println("Pytania już istnieją w bazie.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void importFromFile(String filename) {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(URL, USER, PASSWORD);
            }

            BufferedReader reader = new BufferedReader(new FileReader(filename));
            String line;
            while ((line = reader.readLine()) != null) {
                String question = line.trim();
                String[] answers = new String[4];
                String correct = "";

                for (int i = 0; i < 4; i++) {
                    line = reader.readLine();
                    if (line == null) break;

                    line = line.trim();
                    if (line.startsWith("*")) {
                        correct = switch (i) {
                            case 0 -> "A";
                            case 1 -> "B";
                            case 2 -> "C";
                            case 3 -> "D";
                            default -> "";
                        };
                        answers[i] = line.substring(3).trim();
                    } else {
                        answers[i] = line.substring(2).trim();
                    }
                }

                if (correct.isEmpty()) {

                    continue;
                }

                PreparedStatement ps = conn.prepareStatement("""
                    INSERT INTO questions (question, answerA, answerB, answerC, answerD, correctAnswer)
                    VALUES (?, ?, ?, ?, ?, ?)
                """);

                ps.setString(1, question);
                ps.setString(2, answers[0]);
                ps.setString(3, answers[1]);
                ps.setString(4, answers[2]);
                ps.setString(5, answers[3]);
                ps.setString(6, correct);
                ps.executeUpdate();
                ps.close();
            }

            reader.close();
            System.out.println("Import zakończony!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Question> getRandomQuestions(int count, List<Integer> excludeIds) {
        List<Question> questions = new ArrayList<>();
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(URL, USER, PASSWORD);
            }

            String sql = "SELECT * FROM questions";
            if (excludeIds != null && !excludeIds.isEmpty()) {
                // Tworzymy parametry do NOT IN (?, ?, ...)
                StringBuilder placeholders = new StringBuilder();
                for (int i = 0; i < excludeIds.size(); i++) {
                    placeholders.append("?");
                    if (i < excludeIds.size() - 1) placeholders.append(",");
                }
                sql += " WHERE id NOT IN (" + placeholders + ")";
            }
            sql += " ORDER BY RAND() LIMIT ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            int paramIndex = 1;
            if (excludeIds != null && !excludeIds.isEmpty()) {
                for (Integer id : excludeIds) {
                    ps.setInt(paramIndex++, id);
                }
            }
            ps.setInt(paramIndex, count);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Question q = new Question(
                        rs.getInt("id"),
                        rs.getString("question"),
                        rs.getString("answerA"),
                        rs.getString("answerB"),
                        rs.getString("answerC"),
                        rs.getString("answerD"),
                        rs.getString("correctAnswer").charAt(0)
                );
                questions.add(q);
            }

            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questions;
    }
    public void saveResult(String username, int score, int total) {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(URL, USER, PASSWORD);
            }

            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO results (username, score, total) VALUES (?, ?, ?)"
            );
            ps.setString(1, username);
            ps.setInt(2, score);
            ps.setInt(3, total);
            ps.executeUpdate();
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
