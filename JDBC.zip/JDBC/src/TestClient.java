import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TestClient {
    public static void main(String[] args) {
        DBManager.initializeDatabase();
        DBManager db = new DBManager();

        List<Integer> usedIds = new ArrayList<>();
        int totalQuestionsToAsk = 10;
        int batchSize = 3;  // ile pytań na rundę

        Scanner scanner = new Scanner(System.in);
        int correct = 0;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        boolean exitRequested = false;


        while (usedIds.size() < totalQuestionsToAsk  && !exitRequested) {
            int remaining = totalQuestionsToAsk - usedIds.size();
            int toAskNow = Math.min(batchSize, remaining);

            List<Question> questions = db.getRandomQuestions(toAskNow, usedIds);
            if (questions.isEmpty()) {
                System.out.println("Brak nowych pytań do wylosowania.");
                break;
            }

            for (Question q : questions) {
                System.out.println(q.question);
                System.out.println("A) " + q.a);
                System.out.println("B) " + q.b);
                System.out.println("C) " + q.c);
                System.out.println("D) " + q.d);
                System.out.print("Odpowiedź (masz 10 sekund, wpisz 'exit' aby zakończyć): ");

                String input = null;
                try {
                    input = readLineWithTimeout(reader, 10);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                if (input == null) {
                    System.out.println("\nPrzekroczono czas na odpowiedź!");
                } else {
                    input = input.trim();
                    if (input.equalsIgnoreCase("exit")) {
                        System.out.println("Wyjście z Quizu.");
                        exitRequested = true;
                        break;  // wychodzimy z pętli pytań
                    }

                    input = input.toUpperCase();
                    if (input.length() > 0 && input.charAt(0) == q.correct) {
                        correct++;
                    }
                }

                usedIds.add(q.id);
            }
        }

        System.out.println("Wynik: " + correct + "/" + usedIds.size());

        System.out.print("Podaj swoje imię i nazwisko: ");
        String username = scanner.nextLine().trim();

        // tutaj zamiast questions.size() używamy usedIds.size()
        db.saveResult(username, correct, usedIds.size());

        System.out.println("Wynik został zapisany. Dziękujemy za udział w quizie!");
    }

    private static String readLineWithTimeout(BufferedReader reader, int timeoutSeconds) throws IOException {
        long endTime = System.currentTimeMillis() + timeoutSeconds * 1000;

        while (System.currentTimeMillis() < endTime) {
            if (System.in.available() > 0) {
                return reader.readLine();
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                return null;
            }
        }
        return null; // timeout
    }
}
