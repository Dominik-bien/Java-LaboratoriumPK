import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

public class TestServer {
    private static final int PORT = 12345;
    private static final int MAX_CLIENTS = 250;
    private static final int TIMEOUT_MS = 25000;

    private static List<List<String>> questions = new ArrayList<>();
    private static List<String> correctAnswers = new ArrayList<>();
    private static final Object fileLock = new Object();

    public static void main(String[] args) {
        DBManager.initializeDatabase();
        DBManager db = new DBManager();
        db.importFromFile("src/bazaPytan.txt");

        ExecutorService executor = Executors.newFixedThreadPool(MAX_CLIENTS);
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Serwer dziala na porcie " + PORT);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                executor.execute(new ClientHandler(clientSocket));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            executor.shutdown();
        }
    }

    private static void loadQuestionsFromDatabase() {
        try (
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizDB?serverTimezone=UTC", "root", "");
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM questions")
        ) {
            while (rs.next()) {
                List<String> block = new ArrayList<>();
                block.add(rs.getString("question"));
                block.add("A: " + rs.getString("answerA"));
                block.add("B: " + rs.getString("answerB"));
                block.add("C: " + rs.getString("answerC"));
                block.add("D: " + rs.getString("answerD"));

                questions.add(block);
                correctAnswers.add(rs.getString("correctAnswer"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    private static class ClientHandler implements Runnable {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            Socket clientSocket = this.socket; // lokalna kopia

            try (
                    BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                    BufferedWriter out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()))
            ) {
                List<String> userAnswers = new ArrayList<>();
                int score = 0;

                for (int i = 0; i < questions.size(); i++) {
                    // Wysylamy pytanie
                    List<String> q = questions.get(i);
                    for (String line : q) {
                        try {
                            out.write(line + "\n");
                        } catch (IOException e) {
                            System.out.println("Klient przerwal połączenie. Zakonczono sesje.");
                            return; // konczymy obsluge tego klienta
                        }
                    }
                    out.flush();

                    clientSocket.setSoTimeout(TIMEOUT_MS);
                    String response;
                    try {
                        response = in.readLine();
                        if (response == null || response.equalsIgnoreCase("exit")) {
                            System.out.println("Klient zakonczyl test.");
                            break;
                        }
                        /*if (response == null) {
                            System.out.println("Klient zakonczyl polaczenie.");
                            break;
                        }
                        if (response.equalsIgnoreCase("exit")) {
                            System.out.println("Klient zakonczyl test.");
                            userAnswers.add("Pytanie " + (i + 1) + ": exit");
                            break;
                        }*/

                    } catch (SocketTimeoutException e) {
                        response = "";
                    } catch (IOException e) {
                        System.out.println("Blad odczytu od klienta – zakonczono.");
                        break;
                    }

                    userAnswers.add("Pytanie " + (i + 1) + ": " + response);
                    if (response.equalsIgnoreCase(correctAnswers.get(i))) {
                        score++;
                    }
                }

                /*for (int i = 0; i < questions.size(); i++) {
                    List<String> q = questions.get(i);
                    for (String line : q) {
                        out.write(line + "\n");
                    }
                    out.flush();

                    clientSocket.setSoTimeout(TIMEOUT_MS);
                    String response;
                    try {
                        response = in.readLine();
                        if (response == null || response.equalsIgnoreCase("exit")) break;
                    } catch (SocketTimeoutException e) {
                        response = "";
                    }


                    userAnswers.add("Pytanie " + (i + 1) + ": " + response);
                    if (response.equalsIgnoreCase(correctAnswers.get(i))) {
                        score++;
                    }
                }*/

                synchronized (fileLock) {
                    try (BufferedWriter answersWriter = new BufferedWriter(new FileWriter("src/bazaOdpowiedzi.txt", true))) {
                        for (String ans : userAnswers) {
                            answersWriter.write(ans + "\n");
                        }
                        answersWriter.write("----\n");
                    } catch (IOException e) {
                        e.printStackTrace(); // Obsługa zapisu do pliku
                    }

                    // Dodaj ten blok try-catch, aby obsłużyć SQLException
                    try (
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizDB?serverTimezone=UTC", "root", "");
                            PreparedStatement ps = conn.prepareStatement("INSERT INTO results (score, total) VALUES (?, ?)")
                    ) {
                        ps.setInt(1, score);
                        ps.setInt(2, questions.size());
                        ps.executeUpdate();
                    } catch (SQLException e) {
                        e.printStackTrace(); // Obsługa błędu zapisu do bazy danych
                    }
                }

                //System.out.println("Klient ukonczyl test. Wynik: " + score + "/" + questions.size());


                out.write("Twoj wynik: " + score + "/" + questions.size() + "\n");
                out.flush();

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }



    }
}