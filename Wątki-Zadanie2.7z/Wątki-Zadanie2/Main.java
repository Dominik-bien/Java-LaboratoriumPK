import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        TaskManager manager = new TaskManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nWybierz opcję:");
            System.out.println("1 - Dodaj nowe zadanie");
            System.out.println("2 - Sprawdź status zadania");
            System.out.println("3 - Anuluj zadanie");
            System.out.println("4 - Pokaż wynik zadania");
            System.out.println("5 - Wyjdź");

            int option = scanner.nextInt();
            scanner.nextLine(); // konsumowanie końca linii

            switch (option) {
                case 1:
                    // Dodaj zadanie symulujące wykonanie
                    manager.addTask(() -> {
                        int seconds = (int) (Math.random() * 5) + 1;
                        System.out.println("Zadanie uruchomione, czas wykonania: " + seconds + " sekund.");
                        Thread.sleep(seconds * 1000);
                        if (Math.random() < 0.2) { // symuluj błąd w 20% przypadków
                            throw new RuntimeException("Symulowany błąd w zadaniu!");
                        }
                        return "Wykonano w " + seconds + " sekund.";
                    });
                    break;
                case 2:
                    System.out.print("Podaj indeks zadania: ");
                    int statusIndex = scanner.nextInt();
                    manager.checkTaskStatus(statusIndex);
                    break;
                case 3:
                    System.out.print("Podaj indeks zadania do anulowania: ");
                    int cancelIndex = scanner.nextInt();
                    manager.cancelTask(cancelIndex);
                    break;
                case 4:
                    System.out.print("Podaj indeks zadania do pobrania wyniku: ");
                    int resultIndex = scanner.nextInt();
                    manager.getTaskResult(resultIndex);
                    break;
                case 5:
                    manager.shutdown();
                    System.out.println("Koniec programu.");
                    return;
                default:
                    System.out.println("Nieprawidłowa opcja.");
            }
        }
    }
}
