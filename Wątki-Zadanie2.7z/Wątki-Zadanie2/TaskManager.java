import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.*;

public class TaskManager {

    private ExecutorService executor = Executors.newFixedThreadPool(4);
    private List<FutureTask<String>> taskList = new ArrayList<>();

    // Własna wersja FutureTask
    private static class ListeningFutureTask extends FutureTask<String> {
        private final int taskId;

        public ListeningFutureTask(Callable<String> callable, int taskId) {
            super(callable);
            this.taskId = taskId;
        }

        @Override
        protected void done() {
            try {
                if (isCancelled()) {
                    System.out.println("[Zadanie " + taskId + "] Zostało anulowane.");
                } else {
                    String result = get(); // może rzucić wyjątek, obsłużymy poniżej
                    System.out.println("[Zadanie " + taskId + "] Zakończone sukcesem: " + result);
                }
            } catch (InterruptedException e) {
                System.out.println("[Zadanie " + taskId + "] Przerwane: " + e.getMessage());
            } catch (ExecutionException e) {
                System.out.println("[Zadanie " + taskId + "] Błąd podczas wykonania: " + e.getCause());
            }
        }
    }

    // Dodanie nowego zadania
    public void addTask(Callable<String> task) {
        int taskId = taskList.size();
        ListeningFutureTask futureTask = new ListeningFutureTask(task, taskId);
        taskList.add(futureTask);
        executor.execute(futureTask);
    }

    // Sprawdzenie statusu zadania
    public void checkTaskStatus(int index) {
        if (index < 0 || index >= taskList.size()) {
            System.out.println("Nieprawidłowy indeks zadania.");
            return;
        }

        Future<String> future = taskList.get(index);
        if (future.isCancelled()) {
            System.out.println("Zadanie zostało anulowane.");
        } else if (future.isDone()) {
            System.out.println("Zadanie zakończone.");
        } else {
            System.out.println("Zadanie w trakcie wykonywania.");
        }
    }

    // Anulowanie zadania
    public void cancelTask(int index) {
        if (index < 0 || index >= taskList.size()) {
            System.out.println("Nieprawidłowy indeks zadania.");
            return;
        }

        Future<String> future = taskList.get(index);
        boolean cancelled = future.cancel(true);
        if (cancelled) {
            System.out.println("Zadanie zostało anulowane.");
        } else {
            System.out.println("Nie udało się anulować zadania (być może już się zakończyło).");
        }
    }

    // Pobranie wyniku zadania
    public void getTaskResult(int index) {
        if (index < 0 || index >= taskList.size()) {
            System.out.println("Nieprawidłowy indeks zadania.");
            return;
        }

        Future<String> future = taskList.get(index);
        try {
            String result = future.get(); // UWAGA: blokujące wywołanie
            System.out.println("Wynik zadania: " + result);
        } catch (InterruptedException | CancellationException e) {
            System.out.println("Zadanie zostało przerwane lub anulowane.");
        } catch (ExecutionException e) {
            System.out.println("Błąd podczas wykonywania zadania: " + e.getCause());
        }
    }

    // Zamknięcie wykonawcy
    public void shutdown() {
        executor.shutdownNow();
    }

}
